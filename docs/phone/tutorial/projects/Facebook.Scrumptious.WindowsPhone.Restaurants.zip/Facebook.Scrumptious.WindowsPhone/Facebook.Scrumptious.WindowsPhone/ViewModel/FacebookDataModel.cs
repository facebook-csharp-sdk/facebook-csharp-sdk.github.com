﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace Facebook.Scrumptious.WindowsPhone.ViewModel
{
    public class Friend
    {
        public string id { get; set; }
        public string Name { get; set; }
        public Uri PictureUri { get; set; }
    }

    public class Location
    {
        public string Street { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string Zip { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }

        public string Category { get; set; }
        public string Name { get; set; }
        public string Id { get; set; }
        public Uri PictureUri { get; set; }
    }


    public class FacebookData
    {
        private static ObservableCollection<Friend> friends = new ObservableCollection<Friend>();
        public static ObservableCollection<Friend> Friends
        {
            get
            {
                return friends;
            }
        }

        private static ObservableCollection<Friend> selectedFriends = new ObservableCollection<Friend>();
        public static ObservableCollection<Friend> SelectedFriends
        {
            get
            {
                return selectedFriends;
            }
        }

        private static ObservableCollection<Location> locations = new ObservableCollection<Location>();
        public static ObservableCollection<Location> Locations
        {
            get
            {
                return locations;
            }
        }

        private static bool isRestaurantSelected = false;
        public static bool IsRestaurantSelected
        {
            get
            {
                return isRestaurantSelected;
            }
            set
            {
                isRestaurantSelected = value;
            }
        }

        public static Location SelectedRestaurant { get; set; }
    }
}
