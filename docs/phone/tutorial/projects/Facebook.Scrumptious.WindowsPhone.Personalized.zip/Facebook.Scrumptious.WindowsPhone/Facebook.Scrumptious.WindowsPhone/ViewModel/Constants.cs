﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Facebook.Scrumptious.WindowsPhone.ViewModel
{
    class Constants
    {
        public static readonly string FacebookAppId = "540541885996234";
    }
}
